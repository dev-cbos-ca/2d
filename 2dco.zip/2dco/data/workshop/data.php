function get_2d_workshop_data(){
	$items = [
	['group'=>'Wk','code' =>'Wo','name'=>'Wood','load' => 1,'color'=>['hex'=>'#fde5cd','name'=>'orange']],
	['group'=>'Wk','code' =>'At','name'=>'Arts','load' => 1,'color'=>['hex'=>'#fff2cd','name'=>'yellow']],
	['group'=>'Wk','code' =>'Fo','name'=>'Food','load' => 1,'color'=>['hex'=>'#d8ead2','name'=>'green']],
	['group'=>'Wk','code' =>'Cl','name'=>'Cloth','load' => 1,'color'=>['hex'=>'#d1e0e5','name'=>'blue']],
	['group'=>'Wk','code' =>'Rd','name'=>'R&D','load' => 1,'color'=>['hex'=>'#dad2e9','name'=>'violet']],
	['group'=>'Wk','code' =>'St','name'=>'Steel','load' => 1,'color'=>['hex'=>'#f4cccc','name'=>'red']]
	];
	return $items;
}
